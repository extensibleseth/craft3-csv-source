# CSV Source plugin for Craft CMS 3.x

Use CSV data in templates as a Twig variable

![Screenshot](resources/img/plugin-logo.png)

## Requirements

This plugin requires Craft CMS 3.0.0-beta.23 or later.

## Installation

To install the plugin, follow these instructions.

1. Open your terminal and go to your Craft project:

        cd /path/to/project

2. Then tell Composer to load the plugin:

        composer require extensibleseth/csv-source

3. In the Control Panel, go to Settings → Plugins and click the “Install” button for CSV Source.

## CSV Source Overview

-Insert text here-

## Configuring CSV Source

-Insert text here-

## Using CSV Source

-Insert text here-

## CSV Source Roadmap

Some things to do, and ideas for potential features:

* Release it

Brought to you by [Seth Hendrick](https://www.github.com/extensibleseth)
