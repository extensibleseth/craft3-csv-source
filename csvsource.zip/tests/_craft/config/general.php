<?php

return [
    'devMode' => true,
];
